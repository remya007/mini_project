<?php

//create connection
include("connection.php");

$id ="";
$name="";
$branch="";
$dutytime="";

$errorMessage = "";
$successMessage = "";

if( $_SERVER['REQUEST_METHOD'] == 'POST' ) {
$id = $_POST["id"];
$name= $_POST["name"];
$branch= $_POST["branch"];
$dutytime= $_POST["dutytime"];

do{
    if(empty($id) || empty($name) || empty($branch) || empty($dutytime)  ) {
        $errorMessage = "All the feilds are required";
        break;
    }

    // add new doctor

    $sql= "INSERT INTO doctor (id, name, branch, dutytime) VALUES ('$id', '$name', '$branch','$dutytime')";

    $result=mysqli_query($conn,$sql);

    if(!$result){
        $errorMessage = "invalid query: "  . !$conn;
        break;
    }

    $id ="";
    $name="";
    $branch="";
    $dutytime="";

$successMessage = "doctor added correctly";

header("location: /medshoppe/doctorlist.php");
exit;


}while (false);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>pharmacy management system</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div class="container my-5">
        <h2>Add Doctors on duty</h2>


        <?php
        if(!empty($errorMessage)){
            echo "
            <div class='alert alert-warning alert-dismissible fade show' role='alert'>
            <strong>$errorMessage</strong>
            <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='close'></button>
            </div>
            ";
        }

        ?>
        <form method="post">
            <div class="row mb-3">
                <label  class="col-sm-3 col-form-label">Id</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="id" value="<?php echo $id; ?>">
                </div>
            </div>
            
            <div class="row mb-3">
                <label  class="col-sm-3 col-form-label">NAME</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="name" value="<?php echo $name; ?>">
                </div>
            </div>
            <div class="row mb-3">
                <label  class="col-sm-3 col-form-label">Branch</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="branch" value="<?php echo $branch; ?>">
                </div>
            </div>
            <div class="row mb-3">
                <label  class="col-sm-3 col-form-label">Duty time</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="dutytime" value="<?php echo $dutytime; ?>">
                </div>
            </div>
            

            <?php
            if(!empty($successMessage)){
                echo "
                <div class='row mb-3'>
                <div class='offset-sm-3 col-sm-6'>
                <div class='alert alert-success alert-dismissible fade show' role='alert'>
                <strong>$successMessage</strong>
                <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='close'></button>
                </div>
                </div>
                </div>
                ";
            }
    ?>

            <div class="row mb-3">
                <div class="offset-sm-3 col-sm-3 d-grid">
                    <button type="submit" class="btn btn-primary">submit</button>
                </div>
                <div class="col-sm-3 d-grid">
                    <a class="btn btn-outline-primary" href="/medshoppe/doctorlist.php" role="button">cancel</a>
                </div>
            </div>
        </form>
    </div>
  </body>
</html>
<!DOCTYPE html>
<html>
<head>
    <title>Form</title>
</head>
<body>
        <form>
    <link rel="stylesheet" href="index.css">
    <h1>MEDSHOPPE</h1>
            <button>
                <a href="pharmacistlogin.php">pharmacist</a></button>&nbsp;
        
                <button>   
    
                <a href="patientlogin.php">Patient</a></button>&nbsp;

                 <button> 
                <a href="log.php">Admin</a></button>
    
        </form>
</body>
</html>